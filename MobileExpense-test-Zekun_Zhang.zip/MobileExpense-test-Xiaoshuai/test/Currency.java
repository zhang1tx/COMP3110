

public class Currency {

}
